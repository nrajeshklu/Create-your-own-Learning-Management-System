export default `
	.tableSummary {
		display: flex;
	}
	.tableSummaryCol {
		flex: 1;
		text-align: center;
		padding: 30px;
	}
`;