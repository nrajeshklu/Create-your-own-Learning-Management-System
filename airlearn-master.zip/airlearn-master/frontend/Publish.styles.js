export default `
	.summaryInfo {
		text-align: center;
	}
	.linkWrapper {
		margin-top: 10px;
	}
	.headingWrapper {
		margin-top: 30px;
	}
`;