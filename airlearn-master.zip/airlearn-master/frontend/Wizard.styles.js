export default `
	.wizardStep {
		padding: 20px 20px 40px 20px;
	}

	.fieldGroup {
		margin-bottom: 16px;
	}
`;