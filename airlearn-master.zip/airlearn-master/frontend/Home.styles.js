export default `
	.infoChange {
		text-align: center;
		position: fixed;
	    margin: 0 auto;
	    width: 100%;
	    bottom: 60px;
	}
	.linkWrapper {
		margin-top: 10px;
		text-align: center;
	}
`;